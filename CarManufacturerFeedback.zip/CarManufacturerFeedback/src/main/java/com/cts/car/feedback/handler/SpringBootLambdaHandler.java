package com.cts.car.feedback.handler;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.UUID;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClient;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.spec.PutItemSpec;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestStreamHandler;
import com.cts.car.feedback.model.Feedback;

public class SpringBootLambdaHandler implements RequestStreamHandler {

	private DynamoDB dynamoDb;
	private String DYNAMODB_TABLE_NAME = "user_feedback";
    private Regions REGION = Regions.US_WEST_2;	
    
	@Override
	public void handleRequest(InputStream input, OutputStream output, Context context) throws IOException {
		
        JSONObject responseJson = new JSONObject();
        
        AmazonDynamoDBClient client = new AmazonDynamoDBClient();
        client.setRegion(Region.getRegion(REGION));
        this.dynamoDb = new DynamoDB(client);
        
        try {
        	JSONParser parser = new JSONParser();
        	BufferedReader reader = new BufferedReader(new InputStreamReader(input));
        	
        	JSONObject event = (JSONObject) parser.parse(reader);
        	
        	if (event.get("body") != null) {
	            Feedback feedback = new Feedback((String) event.get("body"));
	            
	            this.dynamoDb.getTable(DYNAMODB_TABLE_NAME)
		          .putItem(
		            new PutItemSpec().withItem(new Item()
		              .withPrimaryKey("id", UUID.randomUUID().toString())
		              .withString("name", feedback.getName())
		              .withInt("age", feedback.getAge())
		              .withString("rating", feedback.getRating())));
	        }
        	
        	JSONObject responseBody = new JSONObject();
	        responseBody.put("message", "New item created");
	 
	        JSONObject headerJson = new JSONObject();
	        headerJson.put("x-custom-header", "my custom header value");
	        headerJson.put("Access-Control-Allow-Origin", "*");
	 
	        responseJson.put("statusCode", 200);
	        responseJson.put("headers", headerJson);
	        responseJson.put("body", responseBody.toString());
	        
	        OutputStreamWriter writer = new OutputStreamWriter(output, "UTF-8");
	        writer.write(responseJson.toString());
	        writer.close();
	        
        } catch (Exception e) {
        	
        }
	}

}
