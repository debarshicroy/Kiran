package com.cts.car.feedback.model;

import com.google.gson.Gson;

public class Feedback {
	private String name;
    private int age;
    private String rating;
    
    public Feedback(String json) {
    	Gson gson = new Gson();    	
    	Feedback request = gson.fromJson(json, Feedback.class);
        this.name = request.getName();
        this.age = request.getAge();    	
    	this.rating = request.getRating();
	}
    
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
    
}
