package com.cts.car.feedback;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarManufacturerFeedbackApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarManufacturerFeedbackApplication.class, args);
	}

}
