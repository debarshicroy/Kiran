package com.cts.car.feedback;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarManufacturerFeedbackApplicationTests {

	/*@Test
	void contextLoads() {
	}*/

}
